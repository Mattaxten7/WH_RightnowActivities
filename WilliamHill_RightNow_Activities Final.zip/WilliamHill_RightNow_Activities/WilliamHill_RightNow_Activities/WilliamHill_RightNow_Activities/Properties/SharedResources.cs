﻿
namespace UiPath.Shared.Localization
{
    class SharedResources : WilliamHill_RightNow_Activities.Properties.Resources
    {
    }
}