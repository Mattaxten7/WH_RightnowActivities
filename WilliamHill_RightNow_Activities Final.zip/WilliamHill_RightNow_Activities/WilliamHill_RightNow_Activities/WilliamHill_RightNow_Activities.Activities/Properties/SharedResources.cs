﻿
namespace UiPath.Shared.Localization
{
    class SharedResources : WilliamHill_RightNow_Activities.Activities.Properties.Resources
    {
    }
}