﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Activities;
using RestSharp;
using System.Security;
using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using Microsoft.Win32;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Tar;
using UiPath.Shared.Activities;
using System.Activities.Statements;
using System.Threading;

namespace WH.Rightnow.Activites
{

    public class Queue
    {
        public static string GenerateQueueIDSearch(CodeActivityContext context, bool QueueID, string queueName)
        {
            string queueLookup;
            if (QueueID)
            {
                queueLookup = "queue.id = " + queueName;
            }
            else
            {
                queueLookup = "queue.LookupName = '" + queueName + "'";
            }
            return queueLookup;
        }

        public static bool CheckIfQueueNumeric(CodeActivityContext context, string QueueNameID)
        {
            bool numeric = true;
            try
            {
                Double num = Double.Parse(QueueNameID);

            }
            catch (Exception e)
            {
                numeric = false;
            }
            return numeric;
        }






    }


    public class Auth
    {
        public static void CheckAuthenticationCorrect(string Endpoint, string Auth)
        {
            var client = new RestClient(Endpoint + "/services/rest/connect/v1.4/metadata-catalog/accounts");
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + Auth);
            request.AddHeader("Cookie", "TS01f61f0f=013627b2671720d170bac0324ba8173bf740ed60917157457bb11ad5dbbf2aa26c3579bbc9");
            IRestResponse response = client.Execute(request);
            Common.APISuccess(response);
        }
    }
    public class Contacts
    {
        public static string ExtractIDFromEmail(string Email, string endpoint, string auth)
        {
            var client = new RestClient(endpoint + "/services/rest/connect/v1.4/queryResults/?query=select id from contacts where emails.address= '" + Email + "';");
            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + auth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b2670e3ad3cbeb0a0ffba6ce38519b78c0aac51205737b0e196c16c9bb5d56b902ff");
            IRestResponse response = client.Execute(request);
            Common.APISuccess(response);
            JObject json = JObject.Parse(response.Content);
            string ID = Json.ExtratColumnFromJSON1stResult(json, 0);
            return ID;
        }

        public static string ExtractIDFromOpenBetID(string OpenBetID, string endpoint, string auth)
        {
            var client = new RestClient(endpoint + "/services/rest/connect/v1.4/queryResults/?query=select id from contacts where customFields.c.account_number= '" + OpenBetID + "';");
            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + auth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b2670e3ad3cbeb0a0ffba6ce38519b78c0aac51205737b0e196c16c9bb5d56b902ff");
            IRestResponse response = client.Execute(request);
            Common.APISuccess(response);
            JObject json = JObject.Parse(response.Content);
            string ID = Json.ExtratColumnFromJSON1stResult(json, 0);
            return ID;
        }
        public static string ExtractIDFromEmailStaff(string Email, string endpoint, string auth)
        {
            var client = new RestClient(endpoint + "/services/rest/connect/v1.4/queryResults/?query=select id from accounts where emails.address= '" + Email + "';");
            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + auth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b2670e3ad3cbeb0a0ffba6ce38519b78c0aac51205737b0e196c16c9bb5d56b902ff");
            IRestResponse response = client.Execute(request);
            Common.APISuccess(response);
            JObject json = JObject.Parse(response.Content);
            string ID = Json.ExtratColumnFromJSON1stResult(json, 0);
            return ID;
        }

        public static string ExtractIDFromEmailUser(string Email, string endpoint, string auth)
        {
            var client = new RestClient(endpoint + "/services/rest/connect/v1.4/queryResults/?query=select id from contacts where emails.address= '" + Email + "';");
            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + auth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b2670e3ad3cbeb0a0ffba6ce38519b78c0aac51205737b0e196c16c9bb5d56b902ff");
            IRestResponse response = client.Execute(request);
            Common.APISuccess(response);
            JObject json = JObject.Parse(response.Content);
            string ID = Json.ExtratColumnFromJSON1stResult(json, 0);
            return ID;
        }

        public static string ExtractEmailFromID(string ID, string endpoint, string auth)
        {
            var client = new RestClient(endpoint + "/services/rest/connect/v1.4/queryResults/?query=select emails.address from contacts where id= " + ID + ";");
            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + auth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b2670e3ad3cbeb0a0ffba6ce38519b78c0aac51205737b0e196c16c9bb5d56b902ff");
            IRestResponse response = client.Execute(request);
            JObject json = JObject.Parse(response.Content);
            string Email = Json.CustomJSONExtractionFirstResult(response.Content, "items[0].rows[0][0]");
            return Email;
        }
    }

    public class Accounts
    {
        public static string GetStaffAccountFromUserName(string UserName, string Endpoint, string auth)
        {
            var client = new RestClient(Endpoint + "/services/rest/connect/v1.4/queryResults/?query=select id from accounts where login='" + UserName + "'");
            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + auth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b26750a8749d099b319b82e09f050b12a6b83c76a4a0231821d71d4aea00c543973f");
            IRestResponse response = client.Execute(request);
            JObject jsonTicket = JObject.Parse(response.Content);
            string UserID = (string)jsonTicket.SelectToken("items[0].rows[0][0]");
            return UserID;
        }

        public static string GetQueueID(string Category, string Endpoint, string auth)
        {
            var client = new RestClient(Endpoint + "/services/rest/connect/v1.4/queryResults/?query=select id from serviceCategories where lookupName = '" + Category + "'");
            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + auth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b26750a8749d099b319b82e09f050b12a6b83c76a4a0231821d71d4aea00c543973f");
            IRestResponse response = client.Execute(request);
            JObject jsonTicket = JObject.Parse(response.Content);
            string UserID = (string)jsonTicket.SelectToken("items[0].rows[0][0]");
            return UserID;
        }
    }

    public class Common
    {

        public static string APISuccess(IRestResponse response)
        {
            if (response.StatusCode.ToString() == "OK" || response.StatusCode.ToString() == "Created")
            {
                return (response.Content);
            }
            else
            {
                throw new Exception("Failed to send request response code: " + response.StatusCode.ToString() + "And Response is: " + response.Content.ToString());
            }
        }

        public static string EntryTypeConversion(string EntryType)
        {
            switch (EntryType)
            {
                case "Private_Note":
                    return "1";
                case "Response":
                    return "2";

                case "Customer_Entry":
                    return "3";



            }
            return null;
        }

        public RestRequest RequiredHeaders(string APIKey, RestRequest request)
        {
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + APIKey);
            request.AddHeader("Cookie", "TS01f61f0f=013627b267c4365d65719eaf55cedd325a11dd6c6ac37f70b57b63ada31bd2b293ee799936");
            return request;
        }
        public RestRequest RequiredHeadersJSON(string endpoint, RestRequest request)
        {
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + endpoint);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b267e9865800c3bf861857895170ec75a8a28c8c58fc9f032898296a160f3289ecf4");
            return request;
        }

        public static void AdvancedDebugging(IRestResponse response)
        {
            Console.WriteLine("The response is " + response.Content);
            Console.WriteLine("The status code is " + response.StatusCode);
            Console.WriteLine("The request URL was " + response.ResponseUri.AbsoluteUri);
        }
    }

    public class EncodeDecode
    {
        public static string Base64Encode(string FilePath)
        {
            byte[] bytes = File.ReadAllBytes(FilePath);
            string file = Convert.ToBase64String(bytes);
            return file;

        }

        public static string Base64EncodeCredential(string UserNamePass)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(UserNamePass);
            return System.Convert.ToBase64String(plainTextBytes);

        }
    }

    public class FileAttachments
    {
        public static void ExtractTGZ(String gzArchiveName, String destFolder)
        {
            Stream inStream = File.OpenRead(gzArchiveName);
            Stream gzipStream = new GZipInputStream(inStream);
            TarArchive tarArchive = TarArchive.CreateInputTarArchive(gzipStream);
            tarArchive.ExtractContents(destFolder);
            tarArchive.Close();

            gzipStream.Close();
            inStream.Close();
        }
    }

    public class Json
    {
        public static List<string> ExtratColumnFromJSON(JObject json, List<string> TicketsResult, int columnNumber)
        {
            string href = "first";
            int i = 0;
            bool stop = false;
            while (!string.IsNullOrEmpty(href) && stop == false)
            {


                try
                {
                    TicketsResult.Add(System.Text.RegularExpressions.Regex.Match((string)json.SelectToken("items[" + columnNumber.ToString() + "].rows[" + i + "][0]").ToString(), "\\d+").ToString());
                }
                catch
                {
                    stop = true;
                }


                i++;
            }
            return TicketsResult;
        }

        public static List<string> ExtratColumnFromIncLookupName(JObject json, List<string> TicketsResult, int columnNumber)
        {
            string href = "first";
            int i = 0;
            bool stop = false;
            while (!string.IsNullOrEmpty(href) && stop == false)
            {


                try
                {
                    string ticketresult = json.SelectToken("items[" + columnNumber.ToString() + "].rows[" + i + "][0]").ToString();
                    TicketsResult.Add(ticketresult + "|" + json.SelectToken("items[" + columnNumber.ToString() + "].rows[" + i + "][1]").ToString());
                }
                catch
                {
                    stop = true;
                }


                i++;
            }
            return TicketsResult;
        }

        public static List<string> ExtratColumnFromNoLookupName(JObject json, List<string> TicketsResult, int columnNumber)
        {
            string href = "first";
            int i = 0;
            bool stop = false;
            while (!string.IsNullOrEmpty(href) && stop == false)
            {


                try
                {
                    string ticketresult = json.SelectToken("items[" + columnNumber.ToString() + "].rows[" + i + "][0]").ToString();
                    TicketsResult.Add(ticketresult);
                }
                catch
                {
                    stop = true;
                }


                i++;
            }
            return TicketsResult;
        }

        public static string ExtratColumnFromJSON1stResult(JObject json, int columnNumber)
        {
            string href = "first";
            string TicketResult = "";
            int i = 0;
            bool stop = false;
            while (!string.IsNullOrEmpty(href) && stop == false)
            {

                try
                {
                    TicketResult = System.Text.RegularExpressions.Regex.Match((string)json.SelectToken("items[" + columnNumber.ToString() + "].rows[" + i + "]").ToString(), "\\d+").ToString();
                    stop = true;
                }
                catch
                {
                    stop = true;
                }


                i++;
            }
            return TicketResult;
        }

        public static string ExtratColumnFromJSON1stResultNonInt(JObject json, int columnNumber)
        {
            string href = "first";
            string TicketResult = "";
            int i = 0;
            bool stop = false;
            while (!string.IsNullOrEmpty(href) && stop == false)
            {

                try
                {
                    TicketResult = System.Text.RegularExpressions.Regex.Match((string)json.SelectToken("items[" + columnNumber.ToString() + "].rows[" + i + "]").ToString(), "\\d+").ToString();
                    stop = true;
                }
                catch
                {
                    stop = true;
                }


                i++;
            }
            return TicketResult;
        }
        public static string CustomJSONExtractionFirstResult(string Stringjson, string query)
        {
            string href = "first";
            string TicketResult = "";
            JObject json = JObject.Parse(Stringjson);
            int i = 0;
            bool stop = false;
            while (!string.IsNullOrEmpty(href) && stop == false)
            {
                ;

                try
                {
                    TicketResult = (string)json.SelectToken(query).ToString();
                    stop = true;
                }
                catch
                {
                    stop = true;
                }


                i++;
            }
            return TicketResult;
        }

        public static List<string> CustomJSONExtractionAllResults(string Stringjson, string query,string letterToReplace)
        {
            string href = "first";
            List<string> TicketResult = new List<string>();
            JObject json = JObject.Parse(Stringjson);
            int i = 0;
            bool stop = false;
            while (!string.IsNullOrEmpty(href) && stop == false)
            {
                ;

                try
                {
                    TicketResult.Add((string)json.SelectToken(query.Replace(letterToReplace,i.ToString())).ToString());
                }
                catch
                {
                    stop = true;
                }


                i++;
            }
            return TicketResult;
        }
    }
}

