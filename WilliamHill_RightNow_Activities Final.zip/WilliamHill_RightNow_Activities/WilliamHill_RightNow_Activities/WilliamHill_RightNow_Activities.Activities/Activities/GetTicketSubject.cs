using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using WH.Rightnow.Activites;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.GetTicketSubject_DisplayName))]
    [LocalizedDescription(nameof(Resources.GetTicketSubject_Description))]
    public class GetTicketSubject : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.GetTicketSubject_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.GetTicketSubject_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket { get; set; }


        [LocalizedDisplayName(nameof(Resources.GetTicketSubject_Subject_DisplayName))]
        [LocalizedDescription(nameof(Resources.GetTicketSubject_Subject_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Subject { get; set; }

        #endregion


        #region Constructors

        public GetTicketSubject()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs
            var ticket = Ticket.Get(context);
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


           string SecureAPIKey =Scope.APICredential;
           string EndPoint =Scope.Endpoint;
            bool advancedDebugging = Scope.AdvancedDebugging;
           
            var client = new RestClient(EndPoint +"/services/rest/connect/v1.4/queryResults/?query=select subject from incidents where id = "+ ticket);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic "+ SecureAPIKey);
            request.AddHeader("Cookie", "TS01f61f0f=013627b267c0f28bfc056807c32c79bbd198336cec4c537dfd1c72d9d0c2a4bf459ac3fd43");
            IRestResponse response = client.Execute(request);
            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            Common.APISuccess(response);
           Subject.Set(context,Json.CustomJSONExtractionFirstResult(response.Content, "items[0].rows[0][0]"));

          
        }

        #endregion
    }
}

