using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using WH.Rightnow.Activites;
using System.ComponentModel;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.UpdateTicketSubject_DisplayName))]
    [LocalizedDescription(nameof(Resources.UpdateTicketSubject_Description))]
    public class UpdateTicketSubject : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.UpdateTicketSubject_EndPoint_DisplayName))]
        [LocalizedDescription(nameof(Resources.UpdateTicketSubject_EndPoint_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> EndPoint { get; set; }

        [LocalizedDisplayName(nameof(Resources.UpdateTicketSubject_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.UpdateTicketSubject_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket { get; set; }

        [LocalizedDisplayName(nameof(Resources.UpdateTicketSubject_SecureAPIKey_DisplayName))]
        [LocalizedDescription(nameof(Resources.UpdateTicketSubject_SecureAPIKey_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> SecureAPIKey { get; set; }

        [LocalizedDisplayName(nameof(Resources.UpdateTicketSubject_Subject_DisplayName))]
        [LocalizedDescription(nameof(Resources.UpdateTicketSubject_Subject_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Subject { get; set; }

        [LocalizedDisplayName(nameof(Resources.UpdateTicketSubject_Response_DisplayName))]
        [LocalizedDescription(nameof(Resources.UpdateTicketSubject_Response_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Response { get; set; }

        #endregion


        #region Constructors

        public UpdateTicketSubject()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Ticket == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Ticket)));

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;


            var client = new RestClient();
            var request = new RestRequest(Method.PATCH);
            client = new RestClient((EndPoint.Get(context)) + "/services/rest/connect/latest/incidents/" + Ticket.Get(context));
            client.Timeout = 5000;
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b26777dd0b0a77d0eb975347da8dc12c8f3517ec887cea3763a7f409f5fe7b44e11a");
            request.AddParameter("application/json", "{\"subject\":\"" + Subject.Get(context) + "\"}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            Common.APISuccess(response);
            Response.Set(context, response.Content);
        }

        #endregion
    }
}

