using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using WH.Rightnow.Activites;
using System.ComponentModel;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.Update_TicketInfomation_DisplayName))]
    [LocalizedDescription(nameof(Resources.Update_TicketInfomation_Description))]
    public class Update_TicketInfomation : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.Update_TicketInfomation_TicketID_DisplayName))]
        [LocalizedDescription(nameof(Resources.Update_TicketInfomation_TicketID_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> TicketID { get; set; }

        [LocalizedDisplayName(nameof(Resources.Update_TicketInfomation_FieldToUpdate_DisplayName))]
        [LocalizedDescription(nameof(Resources.Update_TicketInfomation_FieldToUpdate_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> FieldToUpdate { get; set; }

        public InArgument<string> Value { get; set; }

        [Description("Some Id's are actually string's if you get a error writing to a ID try this to write back as a string")]
        public InArgument<bool> ValueStringOvervide { get; set; }



        #endregion


        #region Constructors

        public Update_TicketInfomation()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (TicketID == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(TicketID)));
            if (FieldToUpdate == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(FieldToUpdate)));

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            string SecureAPIKey = Scope.APICredential;
            string  EndPoint =Scope.Endpoint;
            var ticketid = TicketID.Get(context);
            var fieldtoupdate = FieldToUpdate.Get(context);
            string value = Value.Get(context);

            string[] rows = fieldtoupdate.Split('.');
            int i = 0;
            string result = "";
            foreach (string row in rows)
            {
                if (i == 0)
                {
                    result = "{\"" + row + "\"" + ":";
                }
                else if (i + 1 == rows.Length)
                {
                    if(ValueStringOvervide.Get(context) == false)
                    {
                    if (fieldtoupdate.Contains("id")) 
                    { 

                    result = result + "{\"" + row + "\"" + ":{ReplaceMe}" + "}";
                    }
                    
                    else
                    {
                    result = result + "{\"" + row + "\"" + ":\"{ReplaceMe}" + "\"}";

                    }

                    }
                    else
                    {
                        result = result + "{\"" + row + "\"" + ":\"{ReplaceMe}" + "\"}";
                    }
                    int j = 0;
                    while (j < i)
                    {
                        result = result + "}";
                        j++;
                    }
                }
                else
                {
                    result = result + "{" + "\"" + row + "\"" + ":";
                }
                i++;
            }
            Console.WriteLine(result.Replace("{ReplaceMe}", value).ToString());
            var client = new RestClient();
            var request = new RestRequest(Method.PATCH);
            client = new RestClient(EndPoint+ "/services/rest/connect/latest/incidents/" + ticketid);
            client.Timeout = 5000;
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b26777dd0b0a77d0eb975347da8dc12c8f3517ec887cea3763a7f409f5fe7b44e11a");
            request.AddParameter("application/json", result.Replace("{ReplaceMe}", value), ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            Common.APISuccess(response);

            // Output
        }

        #endregion
    }
}

