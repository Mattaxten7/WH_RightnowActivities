using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using System.Data;
using WH.Rightnow.Activites;
using System.Collections.Generic;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.ExtractAllThreads_DisplayName))]
    [LocalizedDescription(nameof(Resources.ExtractAllThreads_Description))]
    public class ExtractAllThreads : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.ExtractAllThreads_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.ExtractAllThreads_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket { get; set; }

        [LocalizedDisplayName(nameof(Resources.ExtractAllThreads_Threads_DisplayName))]
        [LocalizedDescription(nameof(Resources.ExtractAllThreads_Threads_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<List<string>> Threads { get; set; }

        #endregion


        #region Constructors

        public ExtractAllThreads()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs
            var ticket = Ticket.Get(context);
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            string SecureAPIKey = Scope.APICredential;
            string EndPoint = Scope.Endpoint;
            bool advancedDebugging = Scope.AdvancedDebugging;

            var client = new RestClient(EndPoint+"/services/rest/connect/v1.4/queryResults/?query=select threads.text from incidents where id = "+ ticket);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic "+SecureAPIKey);
            request.AddHeader("Cookie", "TS01f61f0f=013627b267a26ecb655bf5101fd7ca54be31757739fe3aa576aa0b17165ab16a3f696b12ea");
            IRestResponse response = client.Execute(request);
            Common.AdvancedDebugging(response);
            Common.APISuccess(response);
           List<string> results = Json.CustomJSONExtractionAllResults(response.Content, "items[0].rows[replace][0]", "replace");
            Threads.Set(context, results);
        }

        #endregion
    }
}

