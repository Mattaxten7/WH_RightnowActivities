using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using WH.Rightnow.Activites;
using System.IO;
using RestSharp;
using System.ComponentModel;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.UploadAttachmentToTicket_DisplayName))]
    [LocalizedDescription(nameof(Resources.UploadAttachmentToTicket_Description))]
    public class UploadAttachmentToTicket : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.UploadAttachmentToTicket_EndPoint_DisplayName))]
        [LocalizedDescription(nameof(Resources.UploadAttachmentToTicket_EndPoint_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> EndPoint { get; set; }

        [LocalizedDisplayName(nameof(Resources.UploadAttachmentToTicket_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.UploadAttachmentToTicket_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket { get; set; }

        [LocalizedDisplayName(nameof(Resources.UploadAttachmentToTicket_FilePath_DisplayName))]
        [LocalizedDescription(nameof(Resources.UploadAttachmentToTicket_FilePath_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> FilePath { get; set; }

        [LocalizedDisplayName(nameof(Resources.UploadAttachmentToTicket_Description_DisplayName))]
        [LocalizedDescription(nameof(Resources.UploadAttachmentToTicket_Description_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Description { get; set; }

        [LocalizedDisplayName(nameof(Resources.UploadAttachmentToTicket_SecureAPIKey_DisplayName))]
        [LocalizedDescription(nameof(Resources.UploadAttachmentToTicket_SecureAPIKey_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> SecureAPIKey { get; set; }

        [LocalizedDisplayName(nameof(Resources.UploadAttachmentToTicket_Response_DisplayName))]
        [LocalizedDescription(nameof(Resources.UploadAttachmentToTicket_Response_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Response { get; set; }

        [Browsable(false)]
        [Category("Input")]
        [Description("This is the API Key")]
        public InArgument<string> CustomFileName { get; set; }

        #endregion


        #region Constructors

        public UploadAttachmentToTicket()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Ticket == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Ticket)));

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;
            string base64bytes = EncodeDecode.Base64Encode(FilePath.Get(context));

            FilePath.Set(context, Path.GetFileName(FilePath.Get(context)));

            var client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/incidents/" + Ticket.Get(context) + "/fileAttachments");
            client.Timeout = 5000;
            var request = new RestRequest(Method.POST);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b267ff07aa5d22b2386f743887056b41660cd018e1fa453211aa2ae73eb5341acf61");
            if (string.IsNullOrEmpty(CustomFileName.Get(context)))
            {
                request.AddParameter("application/json", "{\"fileName\":\"" + FilePath.Get(context) + "\",\"data\":\"" + base64bytes + "\"}", ParameterType.RequestBody);
            }
            else
            {
                request.AddParameter("application/json", "{\"fileName\":\"" + CustomFileName.Get(context) + "\",\"data\":\"" + base64bytes + "\"\"description\":\"subject\"}", ParameterType.RequestBody);
            }
            IRestResponse response = client.Execute(request);
            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            Common.APISuccess(response);
            Response.Set(context, response.Content);
        }

        #endregion
    }
}

