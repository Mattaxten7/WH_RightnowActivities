using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using WH.Rightnow.Activites;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Data;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.Extract_TicketInfomation_DisplayName))]
    [LocalizedDescription(nameof(Resources.Extract_TicketInfomation_Description))]
    public class Extract_TicketInfomation : CodeActivity
    {
        #region Properties


        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.Extract_TicketInfomation_Ticket_ID_DisplayName))]
        [LocalizedDescription(nameof(Resources.Extract_TicketInfomation_Ticket_ID_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket_ID { get; set; }

        public OutArgument<DataTable> DT_Ticket { get; set; }


        #endregion


        #region Constructors

        public class Query
        {
            public string URL { get; set; }


            public string Result { get; set; }

            public List<ExtractInfomation> ExtractInfo = new List<ExtractInfomation>();


        }

        public class ExtractInfomation
        {
            public string JSONRequest { get; set; }

            public string Name { get; set; }

            public string Result { get; set; }
        }
        public Extract_TicketInfomation()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Ticket_ID == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Ticket_ID)));

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs
            var ticket_id = Ticket_ID.Get(context);
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();

            Console.WriteLine("Scope okay");
            List<Query> Queries = new List<Query>();

            Query query = new Query();
            query.URL ="/services/rest/connect/v1.4/queryResults/?query=select subject from incidents where id =";
            ExtractInfomation Info = new ExtractInfomation();
            Info.Name = "Subject";
            Info.JSONRequest = "items[0].rows[0][0]";
            query.ExtractInfo.Add(Info);
            Console.WriteLine("Query 1 okay");
            Queries.Add(query);

            query = new Query();
            query.URL = "/services/rest/connect/v1.4/queryResults/?query=select statusWithType.status.id, statusWithType.status.lookupName from incidents where id = ";
            Info = new ExtractInfomation();
            Info.Name = "statusWithType.status.id";
            Info.JSONRequest = "items[0].rows[0][0]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "statusWithType.status.lookupName";
            Info.JSONRequest = "items[0].rows[0][1]";
            query.ExtractInfo.Add(Info);

            Queries.Add(query);

            query = new Query();
            query.URL = "/services/rest/connect/v1.4/queryResults/?query=select queue.id,queue.lookupName from incidents where id = ";
            Info = new ExtractInfomation();
            Info.Name = "queue.id";
            Info.JSONRequest = "items[0].rows[0][0]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "queue.lookupName";
            Info.JSONRequest = "items[0].rows[0][1]";
            query.ExtractInfo.Add(Info);

            Queries.Add(query);

            query = new Query();
            query.URL = "/services/rest/connect/v1.4/queryResults/?query=select category.id,category.lookupName from incidents where id = ";
            Info = new ExtractInfomation();
            Info.Name = "category.id";
            Info.JSONRequest = "items[0].rows[0][0]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "category.lookupName";
            Info.JSONRequest = "items[0].rows[0][1]";
            query.ExtractInfo.Add(Info);

            Queries.Add(query);

            query = new Query();
            query.URL = "/services/rest/connect/v1.4/queryResults/?query=select assignedTo.account.id,assignedTo.account.lookupName from incidents where id = ";
            Info = new ExtractInfomation();
            Info.Name = "assignedTo.account.id";
            Info.JSONRequest = "items[0].rows[0][0]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "assignedTo.account.lookupName";
            Info.JSONRequest = "items[0].rows[0][1]";
            query.ExtractInfo.Add(Info);

            Queries.Add(query);


            query = new Query();
            query.URL = "/services/rest/connect/v1.4/queryResults/?query=select language.id, language.lookupName from incidents where id = ";
            Info = new ExtractInfomation();
            Info.Name = "language.id";
            Info.JSONRequest = "items[0].rows[0][0]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "language.lookupName";
            Info.JSONRequest = "items[0].rows[0][1]";
            query.ExtractInfo.Add(Info);

            Queries.Add(query);



            query = new Query();
            query.URL = "/services/rest/connect/v1.4/queryResults/?query=select customFields.c.account_id, customFields.c.account_status.id,customFields.c.account_status.lookupName,customFields.c.rgm_interaction.id,customFields.c.rgm_interaction.lookupName,customFields.c.rgm_review_reason.id,customFields.c.rgm_review_reason.lookupName,customFields.c.action_score.id,customFields.c.action_score.lookupName,customFields.c.regulatory_body.id,customFields.c.regulatory_body.lookupName from incidents where id = ";
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.account_id";
            Info.JSONRequest = "items[0].rows[0][0]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.account_status.id";
            Info.JSONRequest = "items[0].rows[0][1]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.account_status.lookupName";
            Info.JSONRequest = "items[0].rows[0][2]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.rgm_interaction.id";
            Info.JSONRequest = "items[0].rows[0][3]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.rgm_interaction.LookupName";
            Info.JSONRequest = "items[0].rows[0][4]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.rgm_review_reason.id";
            Info.JSONRequest = "items[0].rows[0][5]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.rgm_review_reason.LookupName";
            Info.JSONRequest = "items[0].rows[0][6]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.action_score.id";
            Info.JSONRequest = "items[0].rows[0][7]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.action_score.LookupName";
            Info.JSONRequest = "items[0].rows[0][8]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.regulatory_body.id";
            Info.JSONRequest = "items[0].rows[0][9]";
            query.ExtractInfo.Add(Info);
            Info = new ExtractInfomation();
            Info.Name = "customFields.c.regulatory_body.LookupName";
            Info.JSONRequest = "items[0].rows[0][10]";
            query.ExtractInfo.Add(Info);

            Queries.Add(query);
            Console.WriteLine("All query's okay");
            DataTable dt = new DataTable();
            dt.Rows.Add();
            

            string SecureAPIKey = Scope.APICredential;
            string EndPoint = Scope.Endpoint;

            foreach(Query invquery in Queries)
            {
                Console.WriteLine(EndPoint + invquery.URL + ticket_id);
            var client = new RestClient(EndPoint + invquery.URL + ticket_id);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey);
            request.AddHeader("Cookie", "TS01f61f0f=013627b267a26ecb655bf5101fd7ca54be31757739fe3aa576aa0b17165ab16a3f696b12ea");
            IRestResponse response = client.Execute(request);
            Common.AdvancedDebugging(response);
            Common.APISuccess(response);
            JObject json = JObject.Parse(response.Content);
            foreach(ExtractInfomation ei in invquery.ExtractInfo)
                {
                    Console.WriteLine(ei.Name);
                    dt.Columns.Add(ei.Name);
                    dt.Rows[0][ei.Name] = json.SelectToken(ei.JSONRequest).ToString();
                }

            }
                DT_Ticket.Set(context, dt);
            // Outputs
        }

        #endregion
    }
}

