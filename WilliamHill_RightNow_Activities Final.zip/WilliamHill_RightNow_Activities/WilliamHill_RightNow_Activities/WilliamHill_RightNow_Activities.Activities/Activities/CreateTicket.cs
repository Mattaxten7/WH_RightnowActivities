using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using WH.Rightnow.Activites;
using RestSharp;
using System.ComponentModel;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.CreateTicket_DisplayName))]
    [LocalizedDescription(nameof(Resources.CreateTicket_Description))]
    public class CreateTicket : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.CreateTicket_EndPoint_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_EndPoint_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> EndPoint { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Subject_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Subject_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Subject { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_AssignTo_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_AssignTo_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> AssignTo { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_AssignToSelf_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_AssignToSelf_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<bool> AssignToSelf { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_SecureAPIKey_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_SecureAPIKey_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> SecureAPIKey { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Queue_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Queue_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Queue { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Product_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Product_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Product { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Category_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Category_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Category { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Response_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Response_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Response { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Note_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Note_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Note { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_CustomerEmail_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_CustomerEmail_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> CustomerEmail { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_CustomerID_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_CustomerID_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> CustomerID { get; set; }

        [Description("Is the customer ID Openbet?")]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<bool> CustomerOpenBet { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Interface_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Interface_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Interface { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Disposition_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Disposition_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Disposition { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_MailBox_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_MailBox_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> MailBox { get; set; }

        [LocalizedDisplayName(nameof(Resources.CreateTicket_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.CreateTicket_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Ticket { get; set; }

        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> LookupName { get; set; }

        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> SummaryInternal { get; set; }

        public enum SendonSave
        {
            Yes,
            No
        }

        public enum ListTicketChoice
        {
            Private_Note,
            Response,
            Customer_Entry
        }
        [Category("Note")]
        [Description("Type of entry")]
        public ListTicketChoice EntryType { get; set; }

        [Category("Note")]
        [Description("Do you want to leave a note?")]
        public SendonSave LeaveNote { get; set; }

        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Description("The regulatory Body name")]
        public InArgument<string> RegulatoryBody { get; set; }

        #endregion


        #region Constructors

        public CreateTicket()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs
            
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;
            AssignTo.Set(context, Accounts.GetStaffAccountFromUserName(Scope.Username, Scope.Endpoint, Scope.APICredential));
            bool QueueNumeric = WH.Rightnow.Activites.Queue.CheckIfQueueNumeric(context, Queue.Get(context));
            string queue;
            if (QueueNumeric)
            {
                queue = "\"id\":" + Queue.Get(context) + "";
            }
            else
            {
                queue = "\"lookupName\":\"" + Queue.Get(context) + "\"";
            }
            Console.WriteLine(queue);
            string Primaryid = "";

            if (string.IsNullOrEmpty(Primaryid) && (CustomerOpenBet.Get(context)))
            {

                    Primaryid = Contacts.ExtractIDFromOpenBetID(CustomerID.Get(context), EndPoint.Get(context), SecureAPIKey.Get(context));
            }
            else
            {


                if (string.IsNullOrEmpty(CustomerEmail.Get(context)))
                {
                    if (!string.IsNullOrEmpty(CustomerID.Get(context)))
                    {
                        Primaryid = CustomerID.Get(context);
                    }
                }
                else
                {
                    Primaryid = Contacts.ExtractIDFromEmail(CustomerEmail.Get(context), EndPoint.Get(context), SecureAPIKey.Get(context));
                }
            }


            if (string.IsNullOrEmpty(Primaryid))
            {
                throw new Exception("The users email provided was not found:" + CustomerEmail.Get(context));
            }
            
            string EntryTypestr = Common.EntryTypeConversion(EntryType.ToString());
            var client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/incidents");
            client.Timeout = 5000;
            var request = new RestRequest(Method.POST);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Content-Type", "application/json");
            Console.WriteLine(EntryType);
            string AssigntoSelfString = "";
            string LeaveNoteString = "";
            string SubjectString = "";
            string QueueString = "";
            string InterfaceString = "";
            string ProductNameString = "";
            string DispositionNameString = "";
            string CategoryString = "";
            string MailBoxString = "";
            string SummaryString = "";
            string regulatorybody = "";

            if (!string.IsNullOrEmpty(RegulatoryBody.Get(context)))
            {
                regulatorybody = ",\r\n\"regulatory_body\":{\"lookupName\":\"" + RegulatoryBody.Get(context) + "\"}";
            }

            if (!string.IsNullOrEmpty(Subject.Get(context)))
            {
                if (string.IsNullOrEmpty(Primaryid))
                {
                    SubjectString = "\r\n\"subject\": \"" + Subject.Get(context) + "\"";
                }
                else
                {
                SubjectString = ",\r\n\"subject\": \"" + Subject.Get(context) + "\"";

                }
            }
            if (!string.IsNullOrEmpty(queue))
            {
                QueueString = ",\r\n\"queue\":{" + queue + "}";
            }
            if (!string.IsNullOrEmpty(Interface.Get(context)))
            {
                InterfaceString = ",\"interface\": {\"lookupName\":\"" + Interface.Get(context) + "\"}";
            }
            if (!string.IsNullOrEmpty(Product.Get(context)))
            {
                ProductNameString = ",\"product\": {\"lookupName\":\"" + Product.Get(context) + "\"}";
            }
            if (!string.IsNullOrEmpty(Disposition.Get(context)))
            {
                DispositionNameString = ",\"disposition\": {\"lookupName\":\"" + Disposition.Get(context) + "\"}";
            }
            if (!string.IsNullOrEmpty(Category.Get(context)))
            {

                int n;
                bool isNumeric = int.TryParse(Category.Get(context), out n);
                if (isNumeric)
                {

                }
                else
                {
                Category.Set(context, Accounts.GetQueueID(Category.Get(context), Scope.Endpoint, Scope.APICredential));

                }

                CategoryString = ",\"category\": {\"id\":" + Category.Get(context) + "}";
            }
            if (!string.IsNullOrEmpty(MailBox.Get(context)))
            {
                MailBoxString = ",\"mailbox\": {\"lookupName\":\"" + MailBox.Get(context) + "\"}";
            }
            if (!string.IsNullOrEmpty(SummaryInternal.Get(context)))
            {
                SummaryString = ",\"summary\": \""+SummaryInternal.Get(context)+"\"";
            }
            Console.WriteLine(SummaryString);
            if (AssignToSelf.Get(context))
            {
                AssigntoSelfString = ",\r\n\"assignedTo\":{\"account\":{\"id\":" + AssignTo.Get(context) + "}}";
            }
            if (LeaveNote.ToString() == "Yes")
            {
                if (EntryType.ToString() == "Private_Note")
                {
                    LeaveNoteString = ",\r\n\"threads\":\r\n{\r\n\"entryType\":\r\n{\r\n\"id\":" + EntryTypestr + "\r\n},\r\n\"text\":\"" + Note.Get(context) + "\"\r\n,\"contentType\":{\"id\":2}}";
                }
                else
                {
                    LeaveNoteString = ",\r\n\"threads\":\r\n{\r\n\"entryType\":\r\n{\r\n\"id\":" + EntryTypestr + "\r\n},\r\n\"text\":\"" + Note.Get(context) + "\"\r\n,\"contentType\":{\"id\":2}}";
                }
            }
            Console.WriteLine("{\r\n\"primaryContact\":\r\n    {\r\n    \"id\":" + Primaryid + "\r\n    }" + SubjectString + LeaveNoteString + QueueString + AssigntoSelfString + ProductNameString + DispositionNameString + CategoryString + MailBoxString +  ",\"customFields\": {\"c\":{\"brand\":{\"lookupName\":\"William Hill\"}"+ SummaryString+ regulatorybody+"}}" + InterfaceString + "\r\n\r\n}");
            if (string.IsNullOrEmpty(Primaryid))
            {
                request.AddParameter("application/json", "{\r" + SubjectString + LeaveNoteString + QueueString + AssigntoSelfString + ProductNameString + DispositionNameString + CategoryString + MailBoxString + ",\"customFields\": {\"c\":{\"brand\":{\"lookupName\":\"William Hill\"}" + SummaryString + regulatorybody + "}}" + InterfaceString + "\r\n\r\n}", ParameterType.RequestBody);
            }
            else
            {
                request.AddParameter("application/json", "{\r\n\"primaryContact\":\r\n    {\r\n    \"id\":" + Primaryid + "\r\n    }" + SubjectString + LeaveNoteString + QueueString + AssigntoSelfString + ProductNameString + DispositionNameString + CategoryString + MailBoxString + ",\"customFields\": {\"c\":{\"brand\":{\"lookupName\":\"William Hill\"}" + SummaryString + regulatorybody+ "}}" + InterfaceString + "\r\n\r\n}", ParameterType.RequestBody);
            }
            

            request.AddHeader("Cookie", "TS01f61f0f=013627b267ce078f6403ea33424df0f24bfbeb815ada4bb0a00bc4fd6d7d560e627e4b74f6");
            IRestResponse response = client.Execute(request);
            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            Common.APISuccess(response);
            string TicketID = Json.CustomJSONExtractionFirstResult(response.Content, "id");
            string lookupName = Json.CustomJSONExtractionFirstResult(response.Content, "lookupName");
            Response.Set(context, response.Content);
            Ticket.Set(context, TicketID);
            LookupName.Set(context, lookupName);







        }

        #endregion
    }
}

