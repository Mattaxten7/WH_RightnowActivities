using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using System.ComponentModel;
using RestSharp;
using WH.Rightnow.Activites;
using Newtonsoft.Json.Linq;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.GetTicketsFromUser_DisplayName))]
    [LocalizedDescription(nameof(Resources.GetTicketsFromUser_Description))]
    public class GetTicketsFromUser : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.GetTicketsFromUser_User_DisplayName))]
        [LocalizedDescription(nameof(Resources.GetTicketsFromUser_User_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> User { get; set; }

        [Browsable(false)]
        public InArgument<string> EndPoint { get; set; }

        [LocalizedDisplayName(nameof(Resources.GetTicketsFromUser_Queue_DisplayName))]
        [LocalizedDescription(nameof(Resources.GetTicketsFromUser_Queue_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Queue { get; set; }

        [LocalizedDisplayName(nameof(Resources.GetTicketsFromUser_SecureAPIKey_DisplayName))]
        [LocalizedDescription(nameof(Resources.GetTicketsFromUser_SecureAPIKey_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> SecureAPIKey { get; set; }

        [LocalizedDisplayName(nameof(Resources.GetTicketsFromUser_Response_DisplayName))]
        [LocalizedDescription(nameof(Resources.GetTicketsFromUser_Response_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Response { get; set; }

        [LocalizedDisplayName(nameof(Resources.GetTicketsFromUser_Tickets_DisplayName))]
        [LocalizedDescription(nameof(Resources.GetTicketsFromUser_Tickets_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<List<string>> Tickets { get; set; }


        [Category("Input")]
        [Description("If you have a very large queue which the API is struggling to extract from then try this. It will slow down the extraction but should work with any queue any size")]
        public InArgument<bool> LargeQueueRequest { get; set; }

        public enum ListTicketChoice
        {
            UnResolved,
            Solved,
            All
        }
        [Category("Input")]
        [RequiredArgument]
        [Description("Type of ticket to extract")]
        public ListTicketChoice Status { get; set; }

        public enum TypeOfUser2
        {
            Staff,
            Customer,
        }
        [Category("Input")]
        [RequiredArgument]
        [Description("Type of user you are searching for")]
        public TypeOfUser2 TypeOfUser { get; set; }


        #endregion


        #region Constructors

        public GetTicketsFromUser()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (User == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(User)));

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs

            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
           RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();

            bool largeTicket = LargeQueueRequest.Get(context);
            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;
            
            List<string> ListTickets = new List<string>();
            var client = new RestClient();

            bool QueueID = WH.Rightnow.Activites.Queue.CheckIfQueueNumeric(context, Queue.Get(context));
            string QueueIDFinal = WH.Rightnow.Activites.Queue.GenerateQueueIDSearch(context, QueueID, Queue.Get(context));
            string typeoftickettoinclude = Status.ToString();
            string typeofuser = TypeOfUser.ToString();
            var client1 = new RestClient();


            if(typeofuser == "Customer")
            {
                User.Set(context, Contacts.ExtractIDFromEmailUser(User.Get(context), Scope.Endpoint, Scope.APICredential));
                if (largeTicket)
                {

                    switch (typeoftickettoinclude)
                    {
                        case "UnResolved":
                            client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 1 and primaryContact.contact = " + User.Get(context));
                            Console.WriteLine(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 1 and primaryContact.contact = " + User.Get(context));
                            break;
                        case "Solved":
                            client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 2 and primaryContact.contact =" + User.Get(context));
                            Console.WriteLine(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 2 and primaryContact.contact =" + User.Get(context));
                            break;

                        default:
                            client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " and primaryContact.contact =   " + User.Get(context));
                            Console.WriteLine(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " and primaryContact.contact = " + User.Get(context));
                            break;
                    }
                    Console.WriteLine(client);
                    client.Timeout = -1;
                    var request = new RestRequest(Method.GET);
                    request.AddHeader("OSvC-CREST-Application-Context", "test");
                    request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                    request.AddHeader("Cookie", "TS01f61f0f=013627b267ff848e41ecf45b19cfd22c970093eeec5dcf21c42c5ea9363a337329b881d023");
                    IRestResponse response = client.Execute(request);
                    Console.WriteLine(response.Content);
                    JObject json = JObject.Parse(response.Content);
                    List<string> TicketsResult = new List<string>();
                    TicketsResult = Json.ExtratColumnFromJSON(json, TicketsResult, 0);
                    Tickets.Set(context, TicketsResult);
                }
                else
                {


                    switch (typeoftickettoinclude)
                    {
                        case "UnResolved":
                            client1 = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 1;");
                            break;
                        case "Solved":
                            client1 = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 2;");
                            break;

                        default:
                            client1 = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + ";");
                            break;
                    }
                    client = client1;


                    client.Timeout = 5000;
                    var request = new RestRequest(Method.GET);
                    request.AddHeader("OSvC-CREST-Application-Context", "test");
                    request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                    request.AddHeader("Cookie", "TS01f61f0f=013627b267c4365d65719eaf55cedd325a11dd6c6ac37f70b57b63ada31bd2b293ee799936");
                    IRestResponse response = client.Execute(request);
                    string APIResponse = Common.APISuccess(response);
                    Response.Set(context, APIResponse);
                    JObject json = JObject.Parse(response.Content);

                    List<string> TicketsResult = new List<string>();
                    TicketsResult = Json.ExtratColumnFromJSON(json, TicketsResult, 0);

                    foreach (string ticket in TicketsResult)
                    {
                        client.Timeout = 5000;
                        request = new RestRequest(Method.GET);
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/incidents/" + ticket);
                        request.AddHeader("OSvC-CREST-Application-Context", "test");
                        request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                        request.AddHeader("Content-Type", "application/json");
                        request.AddHeader("Cookie", "TS01f61f0f=013627b26713ab2e740cb8936e859f4e39a9d4b72621da32763856cf5b689bb39db6ad0cc1");
                        response = client.Execute(request);
                        if (advancedDebugging)
                        {
                            Common.AdvancedDebugging(response);
                        }
                        JObject jsonTicket = JObject.Parse(response.Content);
                        string primarycontact = (string)jsonTicket.SelectToken("primaryContact.links[0].href");
                        if (primarycontact.Contains(User.Get(context)))
                        {
                            ListTickets.Add(ticket.ToString());
                        }

                    }
                    Tickets.Set(context, ListTickets);
                }
            }
            else
            {
                User.Set(context, Contacts.ExtractIDFromEmailStaff(User.Get(context), Scope.Endpoint, Scope.APICredential));
                if (largeTicket)
            {

                switch (typeoftickettoinclude)
                {
                    case "UnResolved":
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 1 and assignedTo.account = "+ User.Get(context));
                        Console.WriteLine(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 1 and assignedTo.account = " + User.Get(context));
                        break;
                    case "Solved":
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 2 and assignedTo.account ="+ User.Get(context));
                        Console.WriteLine(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 2 and assignedTo.account =" + User.Get(context));
                        break;

                    default:
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " and assignedTo.account =   " + User.Get(context));
                        Console.WriteLine(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " and assignedTo.account = " + User.Get(context));
                        break;
                }
                Console.WriteLine(client);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("OSvC-CREST-Application-Context", "test");
                request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                request.AddHeader("Cookie", "TS01f61f0f=013627b267ff848e41ecf45b19cfd22c970093eeec5dcf21c42c5ea9363a337329b881d023");
                IRestResponse response = client.Execute(request);
                Console.WriteLine(response.Content);
                JObject json = JObject.Parse(response.Content);
                List<string> TicketsResult = new List<string>();
                TicketsResult = Json.ExtratColumnFromJSON(json, TicketsResult, 0);
                Tickets.Set(context, TicketsResult);
            }
            else
            {


                switch (typeoftickettoinclude)
                {
                    case "UnResolved":
                        client1 = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 1;");
                        break;
                    case "Solved":
                        client1 = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + " AND StatusWithType.Status = 2;");
                        break;

                    default:
                        client1 = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from incidents where " + QueueIDFinal + ";");
                        break;
                }
                client = client1;


                client.Timeout = 5000;
                var request = new RestRequest(Method.GET);
                request.AddHeader("OSvC-CREST-Application-Context", "test");
                request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                request.AddHeader("Cookie", "TS01f61f0f=013627b267c4365d65719eaf55cedd325a11dd6c6ac37f70b57b63ada31bd2b293ee799936");
                IRestResponse response = client.Execute(request);
                string APIResponse = Common.APISuccess(response);
                Response.Set(context, APIResponse);
                JObject json = JObject.Parse(response.Content);

                List<string> TicketsResult = new List<string>();
                TicketsResult = Json.ExtratColumnFromJSON(json, TicketsResult, 0);

                foreach (string ticket in TicketsResult)
                {
                    client.Timeout = 5000;
                    request = new RestRequest(Method.GET);
                    client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/incidents/" + ticket);
                    request.AddHeader("OSvC-CREST-Application-Context", "test");
                    request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                    request.AddHeader("Content-Type", "application/json");
                    request.AddHeader("Cookie", "TS01f61f0f=013627b26713ab2e740cb8936e859f4e39a9d4b72621da32763856cf5b689bb39db6ad0cc1");
                    response = client.Execute(request);
                    if (advancedDebugging)
                    {
                        Common.AdvancedDebugging(response);
                    }
                    JObject jsonTicket = JObject.Parse(response.Content);
                    string primarycontact = (string)jsonTicket.SelectToken("primaryContact.links[0].href");
                    if (primarycontact.Contains(User.Get(context)))
                    {
                        ListTickets.Add(ticket.ToString());
                    }

                }
                Tickets.Set(context, ListTickets);
            }
            }




        }

        #endregion
    }
}

