using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.ComponentModel;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using WH.Rightnow.Activites;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.Assign_To_Queue_DisplayName))]
    [LocalizedDescription(nameof(Resources.Assign_To_Queue_Description))]
    public class Assign_To_Queue : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [Browsable(false)]
        [Category("Input")]
        [Description("This is the URL for rightnow")]
        public InArgument<string> EndPoint { get; set; }
        [Category("Input")]
        [RequiredArgument]
        [Description("Ticket ID")]
        public InArgument<string> Ticket { get; set; }

        [Browsable(false)]
        [Category("Input")]
        [Description("This is the API Key")]
        public InArgument<string> SecureAPIKey { get; set; }


        [Category("Input")]
        [RequiredArgument]
        [Description("Queue ID or Name")]
        public InArgument<string> Queue { get; set; }

        [Category("Output")]
        [Description("The response as JSON")]
        public OutArgument<string> Response { get; set; }

        #endregion


        #region Constructors

        public Assign_To_Queue()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;
            bool QueueNumeric = WH.Rightnow.Activites.Queue.CheckIfQueueNumeric(context, Queue.Get(context));
            var client = new RestClient((EndPoint.Get(context)) + "/services/rest/connect/latest/incidents/" + Ticket.Get(context));
            client.Timeout = 5000;
            var request = new RestRequest(Method.PATCH);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b267e9865800c3bf861857895170ec75a8a28c8c58fc9f032898296a160f3289ecf4");
            if (QueueNumeric)
            {
                request.AddParameter("application/json", "{\r\n\"queue\": {\"id\":" + Queue.Get(context) + "}\r\n}", ParameterType.RequestBody);
            }
            else
            {
                request.AddParameter("application/json", "{\r\n\"queue\": {\"lookupName\":\"" + Queue.Get(context) + "\"}\r\n}", ParameterType.RequestBody);
            }
            IRestResponse response = client.Execute(request);
            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            Common.APISuccess(response);

            Response.Set(context, response.Content);
        }

        #endregion
    }
}

