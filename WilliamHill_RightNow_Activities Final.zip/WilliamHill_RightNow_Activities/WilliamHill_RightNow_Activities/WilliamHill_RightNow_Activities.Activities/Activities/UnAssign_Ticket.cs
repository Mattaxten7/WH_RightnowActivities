using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.ComponentModel;
using UiPath.Shared.Activities.Utilities;
using WH.Rightnow.Activites;
using RestSharp;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.UnAssign_Ticket_DisplayName))]
    [LocalizedDescription(nameof(Resources.UnAssign_Ticket_Description))]
    public class UnAssign_Ticket : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [Browsable(false)]
        [Category("Input")]
        [Description("This is the URL for rightnow")]
        public InArgument<string> EndPoint { get; set; }
        [Category("Input")]
        [RequiredArgument]
        [Description("ticket ID")]
        public InArgument<string> Ticket { get; set; }

        public enum ListTicketChoice
        {
            UnAssign_Ticket,
            Assign_Ticket
        }
        [Category("Input")]
        [RequiredArgument]
        [Description("want to assign or unassign the ticket")]
        public ListTicketChoice Assign_Ticket { get; set; }

        [Browsable(false)]
        [Category("Assign")]
        [Description("Who to assign the ticket too (ID)")]
        public InArgument<string> Assignee { get; set; }

        [Browsable(false)]
        [Category("Input")]
        [Description("This is the API Key")]
        public InArgument<string> SecureAPIKey { get; set; }

        [Category("Output")]
        [Description("The response as JSON")]
        public OutArgument<string> Response { get; set; }

        #endregion


        #region Constructors

        public UnAssign_Ticket()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;
            if (Assign_Ticket.ToString() == "Assign_Ticket")
            {
                Assignee.Set(context, Accounts.GetStaffAccountFromUserName(Scope.Username, Scope.Endpoint, Scope.APICredential));
                if (string.IsNullOrEmpty(Assignee.Get(context)))
                {
                    throw new Exception("Failed to extract ID from account username: " + Scope.Username);
                }
            }

            var client = new RestClient();
            var request = new RestRequest(Method.PATCH);
            switch (Assign_Ticket.ToString())
            {
                case "UnAssign_Ticket":
                    client = new RestClient((EndPoint.Get(context)) + "/services/rest/connect/latest/incidents/" + Ticket.Get(context));
                    client.Timeout = 5000;
                    request.AddHeader("OSvC-CREST-Application-Context", "test");
                    request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                    request.AddHeader("Content-Type", "application/json");
                    request.AddHeader("Cookie", "TS01f61f0f=013627b267e9865800c3bf861857895170ec75a8a28c8c58fc9f032898296a160f3289ecf4");
                    request.AddParameter("application/json", "{\r\n\"assignedTo\": {\"account\":null,\"staffGroup\":null}\r\n}", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                    if (advancedDebugging)
                    {
                        Common.AdvancedDebugging(response);
                    }
                    Common.APISuccess(response);
                    break;
                case "Assign_Ticket":
                    client = new RestClient((EndPoint.Get(context)) + "/services/rest/connect/latest/incidents/" + Ticket.Get(context));
                    client.Timeout = 5000;
                    request.AddHeader("OSvC-CREST-Application-Context", "test");
                    request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                    request.AddHeader("Content-Type", "application/json");
                    request.AddHeader("Cookie", "TS01f61f0f=013627b267535f362e62fe62b29ad4e531d996c9f8ec34cc82c515719e975eca07b5b33f3a");
                    request.AddParameter("application/json", "{\r\n\"assignedTo\":{\"account\":{\"id\":" + Assignee.Get(context) + "}}}", ParameterType.RequestBody);
                    IRestResponse response2 = client.Execute(request);
                    if (advancedDebugging)
                    {
                        Common.AdvancedDebugging(response2);
                    }
                    Common.APISuccess(response2);
                    break;
            }
            return (ctx) => {
            };
        }

        #endregion
    }
}

