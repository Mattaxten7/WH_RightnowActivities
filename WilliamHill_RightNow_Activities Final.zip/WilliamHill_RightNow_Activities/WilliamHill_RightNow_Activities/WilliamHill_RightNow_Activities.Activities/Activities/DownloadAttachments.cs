using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using WH.Rightnow.Activites;
using Newtonsoft.Json.Linq;
using System.IO;
using System.ComponentModel;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.DownloadAttachments_DisplayName))]
    [LocalizedDescription(nameof(Resources.DownloadAttachments_Description))]
    public class DownloadAttachments : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.DownloadAttachments_EndPoint_DisplayName))]
        [LocalizedDescription(nameof(Resources.DownloadAttachments_EndPoint_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> EndPoint { get; set; }

        [LocalizedDisplayName(nameof(Resources.DownloadAttachments_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.DownloadAttachments_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket { get; set; }

        [LocalizedDisplayName(nameof(Resources.DownloadAttachments_SecureAPIKey_DisplayName))]
        [LocalizedDescription(nameof(Resources.DownloadAttachments_SecureAPIKey_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> SecureAPIKey { get; set; }

        [LocalizedDisplayName(nameof(Resources.DownloadAttachments_SaveTo_DisplayName))]
        [LocalizedDescription(nameof(Resources.DownloadAttachments_SaveTo_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> SaveTo { get; set; }

        [LocalizedDisplayName(nameof(Resources.DownloadAttachments_Response_DisplayName))]
        [LocalizedDescription(nameof(Resources.DownloadAttachments_Response_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public OutArgument<string> Response { get; set; }

        public OutArgument<bool> AttachmentsFound { get; set; }

        [Browsable(false)]
        [LocalizedDisplayName(nameof(Resources.DownloadAttachments_AttachmentChoice_DisplayName))]
        [LocalizedDescription(nameof(Resources.DownloadAttachments_AttachmentChoice_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> AttachmentChoice { get; set; }

        [Description("If true will unzip to the current folder, if false or null will put into a subfolder")]
        public InArgument<bool> UnzipFileInCurrentDirectory { get; set; }

        #endregion


        #region Constructors

        public DownloadAttachments()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Ticket == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Ticket)));

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
           RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();

            AttachmentChoice = "All";
            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;
            var client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/incidents/" + Ticket.Get(context) + "/fileAttachments");
            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Cookie", "TS01f61f0f=013627b267d29fe24709d761503beb8c6ca24cd57c5ad954b2dfe61e36f4876a62ea7e9700");
            IRestResponse response = client.Execute(request);
            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            Common.APISuccess(response);

            JObject json = JObject.Parse(response.Content);
            string href = (string)json.SelectToken("items[0].href");
            if (string.IsNullOrEmpty(href))
            {

                Console.WriteLine("No attachments found on ticket " + Ticket.Get(context));
                AttachmentsFound.Set(context, false);
            }
            else
            {
                AttachmentsFound.Set(context, true);
                Console.WriteLine("Attachments found for ticket " + Ticket.Get(context));

                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/latest/incidents/" + Ticket.Get(context) + "/fileAttachments?download");
                        client.Timeout = -1;
                        request = new RestRequest(Method.GET);
                        request.AddHeader("OSvC-CREST-Application-Context", "test");
                        request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
                        request.AddHeader("Cookie", "TS01f61f0f=013627b2679d5ed0e5ff10cb9d3094946192b439634bab427b51bb01c0de83650029dee78e");
                        response = client.Execute(request);
                        if (advancedDebugging)
                        {
                            Common.AdvancedDebugging(response);
                        }
                        var fileBytes = client.DownloadData(request);
                        Common.APISuccess(response);
                        File.WriteAllBytes(Path.Combine(SaveTo.Get(context), "Downloaded-Attachments.tgz"), fileBytes);
                if (UnzipFileInCurrentDirectory.Get(context))
                {
                    FileAttachments.ExtractTGZ(SaveTo.Get(context) + "Downloaded-Attachments.tgz", SaveTo.Get(context));
                }
                else
                {
                      FileAttachments.ExtractTGZ(SaveTo.Get(context) + "Downloaded-Attachments.tgz", SaveTo.Get(context) + "Downloaded-Attachments");
                }
                        File.Delete(SaveTo.Get(context) + "Downloaded-Attachments.tgz");
                }
            }
        }

        #endregion
    }
