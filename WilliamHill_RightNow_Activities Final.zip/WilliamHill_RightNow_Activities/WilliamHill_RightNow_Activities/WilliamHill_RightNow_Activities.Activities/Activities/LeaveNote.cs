using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using WH.Rightnow.Activites;
using System.ComponentModel;
using System.IO;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.LeaveNote_DisplayName))]
    [LocalizedDescription(nameof(Resources.LeaveNote_Description))]
    public class LeaveNote : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        public enum ListTicketChoice
        {
            Private_Note,
            Response,
            Customer_Entry
        }
        [Category("Threads")]
        [RequiredArgument]
        [Description("EntryType")]

        public ListTicketChoice EntryType { get; set; }

        [LocalizedDisplayName(nameof(Resources.LeaveNote_EndPoint_DisplayName))]
        [LocalizedDescription(nameof(Resources.LeaveNote_EndPoint_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> EndPoint { get; set; }

        [LocalizedDisplayName(nameof(Resources.LeaveNote_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.LeaveNote_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket { get; set; }

        [LocalizedDisplayName(nameof(Resources.LeaveNote_Message_DisplayName))]
        [LocalizedDescription(nameof(Resources.LeaveNote_Message_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Message { get; set; }

        [LocalizedDisplayName(nameof(Resources.LeaveNote_SecureAPIKey_DisplayName))]
        [LocalizedDescription(nameof(Resources.LeaveNote_SecureAPIKey_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        [Browsable(false)]
        public InArgument<string> SecureAPIKey { get; set; }

        [LocalizedDisplayName(nameof(Resources.LeaveNote_Response_DisplayName))]
        [LocalizedDescription(nameof(Resources.LeaveNote_Response_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Response { get; set; }

        [Description("Leave attachment")]
        [Category("Attachments")]
        public InArgument<bool> Attachment { get; set; }

        [Description("FilePath")]
        [Category("Attachments")]
        public InArgument<string> AttachmentPath { get; set; }


        #endregion


        #region Constructors

        public LeaveNote()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (Ticket == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(Ticket)));

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;
            string EntryTypestr = Common.EntryTypeConversion(EntryType.ToString());
            if (string.IsNullOrEmpty(EntryTypestr))
            {
                throw new Exception("Entrytype is not valid");
            }

            var client = new RestClient();
            client.Timeout = 5000;
            var request = new RestRequest(Method.PATCH);
            if (EntryType.ToString() == "Private_Note")
            {
                request = new RestRequest(Method.PATCH);
                client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/incidents/" + Ticket.Get(context));
                request.AddParameter("application/json", "{\r\n\"threads\":\r\n{\r\n\"entryType\":\r\n{\r\n\"id\":" + EntryTypestr + "\r\n},\r\n\"text\":\"" + Message.Get(context) + "\"\r\n,\"contentType\":{\"id\":2}}}", ParameterType.RequestBody);
            }
            else
            {
                if (Attachment.Get(context) == true)
                {
                    string base64bytes = EncodeDecode.Base64Encode(AttachmentPath.Get(context));


                    request = new RestRequest(Method.POST);
                    client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/incidentResponse");
                    request.AddParameter("application/json", "{\"incident\":{\"id\": " + Ticket.Get(context) + ",\"threads\":[{\"text\": \"" + Message.Get(context) + "\",\"entryType\": {\"id\": " + EntryTypestr.ToString() + "},\"contentType\":{\"id\":2}}]},\"fileAttachments\": [{\"fileName\":\""+Path.GetFileName(AttachmentPath.Get(context))+"\",\"data\":\""+base64bytes+"\"}]}", ParameterType.RequestBody);

                }
                else
                {

                request = new RestRequest(Method.POST);
                client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/incidentResponse");
                request.AddParameter("application/json", "{\"incident\":{\"id\": " + Ticket.Get(context) + ",\"threads\":[{\"text\": \"" + Message.Get(context) + "\",\"entryType\": {\"id\": " + EntryTypestr.ToString() + "},\"contentType\":{\"id\":2}}]}}", ParameterType.RequestBody);
                   }
            }

            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b2679c0ad7753942fc5adb566ece4b0fc9939c9a41b65d555fb0e7ded68555d4292c");
            IRestResponse response = client.Execute(request);

            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            Common.APISuccess(response);
            Response.Set(context, response.Content);
        }

        #endregion
    }
}

