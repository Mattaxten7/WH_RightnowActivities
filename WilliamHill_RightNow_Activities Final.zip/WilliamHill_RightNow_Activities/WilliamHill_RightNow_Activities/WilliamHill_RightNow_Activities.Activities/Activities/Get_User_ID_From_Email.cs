using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.ComponentModel;
using UiPath.Shared.Activities.Utilities;
using WH.Rightnow.Activites;
using RestSharp;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.Get_User_ID_From_Email_DisplayName))]
    [LocalizedDescription(nameof(Resources.Get_User_ID_From_Email_Description))]
    public class Get_User_ID_From_Email : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [Category("Input")]
        [Browsable(false)]
        [Description("This is the URL for rightnow")]
        public InArgument<string> EndPoint { get; set; }
        [Category("Input")]
        [RequiredArgument]
        [Description("Users email")]
        public InArgument<string> UserEmail { get; set; }

        [Category("Input")]
        [Browsable(false)]
        [Description("This is the API Key")]
        public InArgument<string> SecureAPIKey { get; set; }


        [Category("Output")]
        [Description("The response as JSON")]
        public OutArgument<string> Response { get; set; }

        [Category("Output")]
        [Description("User ID")]
        public OutArgument<string> UserID { get; set; }

        #endregion


        #region Constructors

        public Get_User_ID_From_Email()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;
            var client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query=select id from contacts where emails.address = '" + UserEmail.Get(context) + "'");
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Cookie", "TS01f61f0f=013627b26705dfefc123d5c73311e3215c17dbfa87f0fd1e237f5d5c22bf1e29b1870b2cd3");
            IRestResponse response = client.Execute(request);
            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            UserID.Set(context, Json.CustomJSONExtractionFirstResult(response.Content, "items[0].rows[0][0]"));
            Common.APISuccess(response);
        }

        #endregion
    }
}

