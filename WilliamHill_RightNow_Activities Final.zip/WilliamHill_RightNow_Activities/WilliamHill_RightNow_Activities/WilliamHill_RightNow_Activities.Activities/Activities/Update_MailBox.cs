using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using System.ComponentModel;
using RestSharp;
using WH.Rightnow.Activites;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.Update_MailBox_DisplayName))]
    [LocalizedDescription(nameof(Resources.Update_MailBox_Description))]
    public class Update_MailBox : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.Update_MailBox_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.Update_MailBox_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket { get; set; }

        [LocalizedDisplayName(nameof(Resources.Update_MailBox_MailBoxNameID_DisplayName))]
        [LocalizedDescription(nameof(Resources.Update_MailBox_MailBoxNameID_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> MailBoxID { get; set; }


        [Browsable(false)]
        public InArgument<string> SecureAPIKey { get; set; }

        [Browsable(false)]
        public InArgument<string> EndPoint { get; set; }

        [Category("Output")]
        [Description("The response as JSON")]
        public OutArgument<string> Response { get; set; }
        #endregion


        #region Constructors

        public Update_MailBox()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var ticket = Ticket.Get(context);
            var mailboxnameid = MailBoxID.Get(context);
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;

            var client = new RestClient();
            var request = new RestRequest(Method.PATCH);
            client = new RestClient((EndPoint.Get(context)) + "/services/rest/connect/latest/incidents/" + Ticket.Get(context));
            client.Timeout = 5000;
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "TS01f61f0f=013627b26777dd0b0a77d0eb975347da8dc12c8f3517ec887cea3763a7f409f5fe7b44e11a");
            request.AddParameter("application/json", "{\"mailbox\":{\"id\":"+mailboxnameid+"}}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            Common.APISuccess(response);
            Response.Set(context, response.Content);

            // Outputs
            return (ctx) => {
            };
        }

        #endregion
    }
}

