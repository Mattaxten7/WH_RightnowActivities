using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using UiPath.Shared.Activities.Utilities;
using RestSharp;
using System.Data;
using WH.Rightnow.Activites;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.ExtractAllThreadsAdvanced_DisplayName))]
    [LocalizedDescription(nameof(Resources.ExtractAllThreadsAdvanced_Description))]
    public class ExtractAllThreadsAdvanced : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [LocalizedDisplayName(nameof(Resources.ExtractAllThreadsAdvanced_Ticket_DisplayName))]
        [LocalizedDescription(nameof(Resources.ExtractAllThreadsAdvanced_Ticket_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> Ticket { get; set; }

        [LocalizedDisplayName(nameof(Resources.ExtractAllThreadsAdvanced_Threads_DisplayName))]
        [LocalizedDescription(nameof(Resources.ExtractAllThreadsAdvanced_Threads_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<DataTable> Threads { get; set; }

        #endregion


        #region Constructors

        public ExtractAllThreadsAdvanced()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs
            var ticket = Ticket.Get(context);
            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();


            string SecureAPIKey = Scope.APICredential;
            string EndPoint = Scope.Endpoint;
            bool advancedDebugging = Scope.AdvancedDebugging;

            var client = new RestClient(EndPoint + "/services/rest/connect/v1.4/queryResults/?query=select threads.text, threads.entryType.lookupName, threads.id, threads.createdTime from incidents where id  = " + ticket);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey);
            request.AddHeader("Cookie", "TS01f61f0f=013627b267a26ecb655bf5101fd7ca54be31757739fe3aa576aa0b17165ab16a3f696b12ea");
            IRestResponse response = client.Execute(request);
            Common.AdvancedDebugging(response);
            Common.APISuccess(response);
            JObject json = JObject.Parse(response.Content);
            List<string> TicketsResult = new List<string>();
            DataTable dt = new DataTable();
            dt.Clear();
            dt.Columns.Add("Text");
            dt.Columns.Add("Entry Type");
            dt.Columns.Add("Thread ID");
            dt.Columns.Add("Created Time");


            string href = "first";
            int i = 0;
            bool stop = false;
            while (!string.IsNullOrEmpty(href) && stop == false)
            {


                try
                {
                    string ticketresult = json.SelectToken("items[0].rows[" + i + "][0]").ToString();
                    ticketresult = ticketresult + "|"+json.SelectToken("items[0].rows[" + i + "][1]").ToString();
                    ticketresult = ticketresult + "|" + json.SelectToken("items[0].rows[" + i + "][2]").ToString();
                    ticketresult = ticketresult + "|" + json.SelectToken("items[0].rows[" + i + "][3]").ToString();

                    TicketsResult.Add(ticketresult);
                }
                catch
                {
                    stop = true;
                }


                i++;
            }

            foreach (string Invticket in TicketsResult)
            {

                {
                    string[] array = Invticket.Split('|');
                    dt.Rows.Add(array[0], array[1], array[2], array[3]);
                }
            }
            Threads.Set(context, dt);
        }

        }

        #endregion
}


