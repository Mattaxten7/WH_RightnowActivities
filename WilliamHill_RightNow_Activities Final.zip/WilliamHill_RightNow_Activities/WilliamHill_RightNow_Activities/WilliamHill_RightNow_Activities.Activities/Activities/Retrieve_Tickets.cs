using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using WilliamHill_RightNow_Activities.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Activities;
using RestSharp;
using System.Security;
using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WH.Rightnow.Activites;
using System.Activities.Statements;
using System.IO;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Utilities;
using System.Data;

namespace WilliamHill_RightNow_Activities.Activities
{
    [LocalizedDisplayName(nameof(Resources.Retrieve_Tickets_DisplayName))]
    [LocalizedDescription(nameof(Resources.Retrieve_Tickets_Description))]
    public class Retrieve_Tickets : CodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>

        [Browsable(false)]
        [Category("Input")]
        [Description("This is the URL for rightnow")]
        public InArgument<string> EndPoint { get; set; }
        [Category("Input")]
        [RequiredArgument]
        [Description("QueueName/ID")]
        public InArgument<string> Queue { get; set; }

        [Browsable(false)]
        [Category("Input")]
        [Description("API Key")]
        public InArgument<string> SecureAPIKey { get; set; }

        [Category("Input")]
        [RequiredArgument]
        [Description("only extract tickets assigned to self")]
        public InArgument<bool> AssignedToSelf { get; set; }

        [Category("Input")]
        [RequiredArgument]
        [Description("Only extract the ID of the tickets [Will allow unlimited results]")]
        public InArgument<bool> OnlyExtractID { get; set; }

        [Category("Input")]
        [RequiredArgument]
        [Description("Do you want to extract it from the report (is a few seconds out of date)")]
        public InArgument<bool> UseReport { get; set; }

        [Browsable(false)]
        [Category("Input")]
        [Description("OwnID")]
        public InArgument<string> SelfID { get; set; }

        public enum ListTicketChoice
        {
            UnResolved,
            Solved,
            All
        }
        [Category("Input")]
        [RequiredArgument]
        [Description("Type of ticket to extract")]
        public ListTicketChoice Status { get; set; }

        [Category("Output")]
        [Description("The response as JSON")]
        public OutArgument<string> Response { get; set; }

        [Category("Output")]
        [RequiredArgument]
        [Description("Returns TicketID and lookupName")]
        public OutArgument<DataTable> Tickets { get; set; }





        #endregion


        #region Constructors

        public Retrieve_Tickets()
        {

        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {

            base.CacheMetadata(metadata);
        }

        protected override void Execute(CodeActivityContext context)
        {
            // Inputs

            var objectContainer = context.GetFromContext<IObjectContainer>(RightNow_Scope.ParentContainerPropertyTag);
            RightNow_Scope.Scope Scope = objectContainer.Get<RightNow_Scope.Scope>();

            if (AssignedToSelf.Get(context) == true)
            {
                SelfID.Set(context, Accounts.GetStaffAccountFromUserName(Scope.Username, Scope.Endpoint, Scope.APICredential));
                if (string.IsNullOrEmpty(SelfID.Get(context)))
                {
                    throw new Exception("Failed to extract ID from account username: " + Scope.Username);
                }
            }

            SecureAPIKey.Set(context, Scope.APICredential);
            EndPoint.Set(context, Scope.Endpoint);
            bool advancedDebugging = Scope.AdvancedDebugging;


            string Columns;
            if (OnlyExtractID.Get(context))
            {
                Columns = "id";
            }
            else
            {
                Columns = "id, lookupName";
            }
            var client = new RestClient();
            string typeoftickettoinclude = Status.ToString();
            string report;
            if (UseReport.Get(context))
            {
                report = "USE REPORT;";
            }
            else
            {
                report = "";
            }
            bool QueueID = WH.Rightnow.Activites.Queue.CheckIfQueueNumeric(context, Queue.Get(context));
            string QueueFinal = WH.Rightnow.Activites.Queue.GenerateQueueIDSearch(context, QueueID, Queue.Get(context));
            switch (typeoftickettoinclude)
            {
                case "UnResolved":
                    if (AssignedToSelf.Get(context))
                    {
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query="+report+"select "+ Columns+" from incidents where " + QueueFinal + " AND StatusWithType.Status = 1 AND assignedTo.account.id = " + SelfID.Get(context) + " ;");
                    }
                    else
                    {
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query="+report+"select "+ Columns +" from incidents where " + QueueFinal + " AND StatusWithType.Status = 1;");

                    }
                    break;
                case "Solved":
                    if (AssignedToSelf.Get(context))
                    {
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query="+report+"select "+ Columns +" from incidents where " + QueueFinal + " AND StatusWithType.Status = 2 AND assignedTo.account.id = " + SelfID.Get(context) + "  ;");
                    }
                    else
                    {
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query="+report+"select "+ Columns +" from incidents where " + QueueFinal + " AND StatusWithType.Status = 2 ;");

                    }
                    break;

                default:

                    if (AssignedToSelf.Get(context))
                    {
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query="+report+"select "+ Columns +" from incidents where " + QueueFinal + "AND assignedTo.accounts.id = '" + SelfID + " ;");
                    }
                    else
                    {
                        client = new RestClient(EndPoint.Get(context) + "/services/rest/connect/v1.4/queryResults/?query="+report+"select "+ Columns +" from incidents where " + QueueFinal + ";");

                    }
                    break;
            }


            client.Timeout = 5000;
            var request = new RestRequest(Method.GET);
            request.AddHeader("OSvC-CREST-Application-Context", "test");
            request.AddHeader("authorization", "Basic " + SecureAPIKey.Get(context));
            request.AddHeader("Cookie", "TS01f61f0f=013627b267c4365d65719eaf55cedd325a11dd6c6ac37f70b57b63ada31bd2b293ee799936");
            IRestResponse response = client.Execute(request);
            string APIResponse = Common.APISuccess(response);
            Response.Set(context, APIResponse);

            if (advancedDebugging)
            {
                Common.AdvancedDebugging(response);
            }
            JObject json = JObject.Parse(response.Content);

            List<string> TicketsResult = new List<string>();
            DataTable dt = new DataTable();
            dt.Clear();
            dt.Columns.Add("TicketID");
            dt.Columns.Add("LookupName");

            if (OnlyExtractID.Get(context))
            {
                TicketsResult = Json.ExtratColumnFromNoLookupName(json, TicketsResult, 0);
            }
            else
            {
                TicketsResult = Json.ExtratColumnFromIncLookupName(json, TicketsResult, 0);
            }

            foreach (string ticket in TicketsResult)
            {

                if (OnlyExtractID.Get(context))
                {
                    dt.Rows.Add(ticket);
                }
                else
                {
                    string[] array = ticket.Split('|');
                    dt.Rows.Add(array[0], array[1]);
                }
            }

            Tickets.Set(context, dt);
        }

        // Outputs
        // return (ctx) => {
    };
        }

        #endregion
   

