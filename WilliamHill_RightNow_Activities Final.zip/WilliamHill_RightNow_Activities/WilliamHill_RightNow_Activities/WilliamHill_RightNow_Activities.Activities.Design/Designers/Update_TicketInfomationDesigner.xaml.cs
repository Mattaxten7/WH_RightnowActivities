namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Update_TicketInfomationDesigner.xaml
    /// </summary>
    public partial class Update_TicketInfomationDesigner
    {
        public Update_TicketInfomationDesigner()
        {
            InitializeComponent();
        }
    }
}
