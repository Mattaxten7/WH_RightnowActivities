namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UnAssign_TicketDesigner.xaml
    /// </summary>
    public partial class UnAssign_TicketDesigner
    {
        public UnAssign_TicketDesigner()
        {
            InitializeComponent();
        }
    }
}
