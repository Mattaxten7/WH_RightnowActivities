namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Get_User_ID_From_EmailDesigner.xaml
    /// </summary>
    public partial class Get_User_ID_From_EmailDesigner
    {
        public Get_User_ID_From_EmailDesigner()
        {
            InitializeComponent();
        }
    }
}
