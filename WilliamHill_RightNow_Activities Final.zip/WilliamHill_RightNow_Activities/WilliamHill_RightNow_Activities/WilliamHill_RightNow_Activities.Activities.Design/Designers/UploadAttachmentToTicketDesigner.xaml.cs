namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UploadAttachmentToTicketDesigner.xaml
    /// </summary>
    public partial class UploadAttachmentToTicketDesigner
    {
        public UploadAttachmentToTicketDesigner()
        {
            InitializeComponent();
        }
    }
}
