namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetTicketSubjectDesigner.xaml
    /// </summary>
    public partial class GetTicketSubjectDesigner
    {
        public GetTicketSubjectDesigner()
        {
            InitializeComponent();
        }
    }
}
