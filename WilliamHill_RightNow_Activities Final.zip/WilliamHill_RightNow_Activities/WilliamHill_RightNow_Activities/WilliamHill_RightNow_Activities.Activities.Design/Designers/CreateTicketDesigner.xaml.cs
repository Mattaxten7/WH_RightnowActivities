namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for CreateTicketDesigner.xaml
    /// </summary>
    public partial class CreateTicketDesigner
    {
        public CreateTicketDesigner()
        {
            InitializeComponent();
        }
        private void ExpressionTextBox_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {

        }
    }
}
