namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Update_MailBoxDesigner.xaml
    /// </summary>
    public partial class Update_MailBoxDesigner
    {
        public Update_MailBoxDesigner()
        {
            InitializeComponent();
        }
    }
}
