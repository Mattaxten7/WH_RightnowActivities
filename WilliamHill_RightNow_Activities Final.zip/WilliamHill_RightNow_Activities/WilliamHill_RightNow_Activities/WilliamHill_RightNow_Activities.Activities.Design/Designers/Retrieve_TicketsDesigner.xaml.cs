namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Retrieve_TicketsDesigner.xaml
    /// </summary>
    public partial class Retrieve_TicketsDesigner
    {
        public Retrieve_TicketsDesigner()
        {
            InitializeComponent();
        }
    }
}
