namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Assign_To_QueueDesigner.xaml
    /// </summary>
    public partial class Assign_To_QueueDesigner
    {
        public Assign_To_QueueDesigner()
        {
            InitializeComponent();
        }
    }
}
