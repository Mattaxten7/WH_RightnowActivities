namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetTicketsFromUserDesigner.xaml
    /// </summary>
    public partial class GetTicketsFromUserDesigner
    {
        public GetTicketsFromUserDesigner()
        {
            InitializeComponent();
        }
    }
}
