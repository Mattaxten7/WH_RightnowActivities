namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for DownloadAttachmentsDesigner.xaml
    /// </summary>
    public partial class DownloadAttachmentsDesigner
    {
        public DownloadAttachmentsDesigner()
        {
            InitializeComponent();
        }
    }
}
