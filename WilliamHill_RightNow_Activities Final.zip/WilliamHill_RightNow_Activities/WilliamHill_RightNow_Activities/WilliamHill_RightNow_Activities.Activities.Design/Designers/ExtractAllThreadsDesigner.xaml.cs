namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for ExtractAllThreadsDesigner.xaml
    /// </summary>
    public partial class ExtractAllThreadsDesigner
    {
        public ExtractAllThreadsDesigner()
        {
            InitializeComponent();
        }
    }
}
