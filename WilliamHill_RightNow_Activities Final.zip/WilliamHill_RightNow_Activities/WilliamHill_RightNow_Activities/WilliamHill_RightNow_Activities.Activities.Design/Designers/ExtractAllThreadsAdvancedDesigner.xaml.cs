namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for ExtractAllThreadsAdvancedDesigner.xaml
    /// </summary>
    public partial class ExtractAllThreadsAdvancedDesigner
    {
        public ExtractAllThreadsAdvancedDesigner()
        {
            InitializeComponent();
        }
    }
}
