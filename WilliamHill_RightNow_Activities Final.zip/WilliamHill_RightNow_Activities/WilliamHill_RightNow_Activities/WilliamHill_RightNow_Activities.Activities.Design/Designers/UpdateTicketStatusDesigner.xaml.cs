namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UpdateTicketStatusDesigner.xaml
    /// </summary>
    public partial class UpdateTicketStatusDesigner
    {
        public UpdateTicketStatusDesigner()
        {
            InitializeComponent();
        }
    }
}
