namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Extract_TicketInfomationDesigner.xaml
    /// </summary>
    public partial class Extract_TicketInfomationDesigner
    {
        public Extract_TicketInfomationDesigner()
        {
            InitializeComponent();
        }
    }
}
