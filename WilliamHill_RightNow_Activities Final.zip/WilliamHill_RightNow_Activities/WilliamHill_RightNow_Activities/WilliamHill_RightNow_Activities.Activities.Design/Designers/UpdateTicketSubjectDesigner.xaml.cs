namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UpdateTicketSubjectDesigner.xaml
    /// </summary>
    public partial class UpdateTicketSubjectDesigner
    {
        public UpdateTicketSubjectDesigner()
        {
            InitializeComponent();
        }
    }
}
