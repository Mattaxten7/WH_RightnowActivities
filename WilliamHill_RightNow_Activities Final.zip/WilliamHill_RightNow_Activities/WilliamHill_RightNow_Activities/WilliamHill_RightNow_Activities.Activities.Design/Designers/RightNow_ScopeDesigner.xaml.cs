namespace WilliamHill_RightNow_Activities.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for RightNow_ScopeDesigner.xaml
    /// </summary>
    public partial class RightNow_ScopeDesigner
    {
        public RightNow_ScopeDesigner()
        {
            InitializeComponent();
        }
    }
}
