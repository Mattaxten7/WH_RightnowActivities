﻿
namespace UiPath.Shared.Localization
{
    class SharedResources : WilliamHill_RightNow_Activities.Activities.Design.Properties.Resources
    {
    }
}