using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using WilliamHill_RightNow_Activities.Activities.Design.Designers;
using WilliamHill_RightNow_Activities.Activities.Design.Properties;

namespace WilliamHill_RightNow_Activities.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(Retrieve_Tickets), categoryAttribute);
            builder.AddCustomAttributes(typeof(Retrieve_Tickets), new DesignerAttribute(typeof(Retrieve_TicketsDesigner)));
            builder.AddCustomAttributes(typeof(Retrieve_Tickets), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(RightNow_Scope), categoryAttribute);
            builder.AddCustomAttributes(typeof(RightNow_Scope), new DesignerAttribute(typeof(RightNow_ScopeDesigner)));
            builder.AddCustomAttributes(typeof(RightNow_Scope), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(UnAssign_Ticket), categoryAttribute);
            builder.AddCustomAttributes(typeof(UnAssign_Ticket), new DesignerAttribute(typeof(UnAssign_TicketDesigner)));
            builder.AddCustomAttributes(typeof(UnAssign_Ticket), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(Assign_To_Queue), categoryAttribute);
            builder.AddCustomAttributes(typeof(Assign_To_Queue), new DesignerAttribute(typeof(Assign_To_QueueDesigner)));
            builder.AddCustomAttributes(typeof(Assign_To_Queue), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(Get_User_ID_From_Email), categoryAttribute);
            builder.AddCustomAttributes(typeof(Get_User_ID_From_Email), new DesignerAttribute(typeof(Get_User_ID_From_EmailDesigner)));
            builder.AddCustomAttributes(typeof(Get_User_ID_From_Email), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(GetTicketsFromUser), categoryAttribute);
            builder.AddCustomAttributes(typeof(GetTicketsFromUser), new DesignerAttribute(typeof(GetTicketsFromUserDesigner)));
            builder.AddCustomAttributes(typeof(GetTicketsFromUser), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(UploadAttachmentToTicket), categoryAttribute);
            builder.AddCustomAttributes(typeof(UploadAttachmentToTicket), new DesignerAttribute(typeof(UploadAttachmentToTicketDesigner)));
            builder.AddCustomAttributes(typeof(UploadAttachmentToTicket), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(DownloadAttachments), categoryAttribute);
            builder.AddCustomAttributes(typeof(DownloadAttachments), new DesignerAttribute(typeof(DownloadAttachmentsDesigner)));
            builder.AddCustomAttributes(typeof(DownloadAttachments), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(UpdateTicketStatus), categoryAttribute);
            builder.AddCustomAttributes(typeof(UpdateTicketStatus), new DesignerAttribute(typeof(UpdateTicketStatusDesigner)));
            builder.AddCustomAttributes(typeof(UpdateTicketStatus), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(UpdateTicketSubject), categoryAttribute);
            builder.AddCustomAttributes(typeof(UpdateTicketSubject), new DesignerAttribute(typeof(UpdateTicketSubjectDesigner)));
            builder.AddCustomAttributes(typeof(UpdateTicketSubject), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(CreateTicket), categoryAttribute);
            builder.AddCustomAttributes(typeof(CreateTicket), new DesignerAttribute(typeof(CreateTicketDesigner)));
            builder.AddCustomAttributes(typeof(CreateTicket), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(LeaveNote), categoryAttribute);
            builder.AddCustomAttributes(typeof(LeaveNote), new DesignerAttribute(typeof(LeaveNoteDesigner)));
            builder.AddCustomAttributes(typeof(LeaveNote), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(GetTicketSubject), categoryAttribute);
            builder.AddCustomAttributes(typeof(GetTicketSubject), new DesignerAttribute(typeof(GetTicketSubjectDesigner)));
            builder.AddCustomAttributes(typeof(GetTicketSubject), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(ExtractAllThreads), categoryAttribute);
            builder.AddCustomAttributes(typeof(ExtractAllThreads), new DesignerAttribute(typeof(ExtractAllThreadsDesigner)));
            builder.AddCustomAttributes(typeof(ExtractAllThreads), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(Update_MailBox), categoryAttribute);
            builder.AddCustomAttributes(typeof(Update_MailBox), new DesignerAttribute(typeof(Update_MailBoxDesigner)));
            builder.AddCustomAttributes(typeof(Update_MailBox), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(ExtractAllThreadsAdvanced), categoryAttribute);
            builder.AddCustomAttributes(typeof(ExtractAllThreadsAdvanced), new DesignerAttribute(typeof(ExtractAllThreadsAdvancedDesigner)));
            builder.AddCustomAttributes(typeof(ExtractAllThreadsAdvanced), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(Extract_TicketInfomation), categoryAttribute);
            builder.AddCustomAttributes(typeof(Extract_TicketInfomation), new DesignerAttribute(typeof(Extract_TicketInfomationDesigner)));
            builder.AddCustomAttributes(typeof(Extract_TicketInfomation), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(Update_TicketInfomation), categoryAttribute);
            builder.AddCustomAttributes(typeof(Update_TicketInfomation), new DesignerAttribute(typeof(Update_TicketInfomationDesigner)));
            builder.AddCustomAttributes(typeof(Update_TicketInfomation), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
