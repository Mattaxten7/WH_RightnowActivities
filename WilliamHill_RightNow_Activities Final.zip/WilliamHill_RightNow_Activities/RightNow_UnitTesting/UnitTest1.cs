using System;
using Xunit;
using WH.Rightnow.Activites;
using WilliamHill_RightNow_Activities.Activities;

namespace RightNow_UnitTesting
{
    public class AssignToQueueTest
    {
       
    }
}
